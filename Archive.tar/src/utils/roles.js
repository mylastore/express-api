module.exports = {

  customer: ["/api/v1/users","/api/v1/categories","/api/v1/meetups"],
  admin: ["/api/v1/admin", "/api/v1/users",  "/api/v1/categories"],
  manager: ["/api/v1/manager"]

};